module.exports = {
  layouts: {
    all: require('./layouts/all.json')
  }
};
